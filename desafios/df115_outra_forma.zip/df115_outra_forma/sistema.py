from desafios.df115.lib.arquivo import criarArquivo
from lib.interface import  *
from lib.arquivo import *
from time import sleep

arq = 'dados.txt'

if arquivoExiste(arq):
    print('Arquivo encontrado com sucesso!')
else:
    print('Arquivo não encontrado!')
    criarArquivo(arq)

while True:
    resposta = menu(['Cadastrar Pessoas', 'Listar Pessoas', 'Sair do Sistema'])
    if resposta == 1:
        submenu('Opção 1')
    elif resposta == 2:
        submenu('Opção 2')
    elif resposta == 3:
        submenu('Saindo do sistema... Até logo!')
        break
    else:
        print('\033[31mERRO! Digite uma opção válida!\033[m')
    sleep(2)