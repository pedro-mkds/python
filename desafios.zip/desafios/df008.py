#Criarei um conversor de Dolar para Real Brasileiro

d= int(input('Vamos converter sua quantia de Dolares para Reais Brasileiro. Digite um valor: '))
c= d*5.88

print('Você possui: ${} dolares. \n que convertidos são: \n R${}'.format(d,c))