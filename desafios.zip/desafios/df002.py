v = int(input('Digite um valor: '))
v2 = int(input('Digite outro valor: '))

s = v+v2

print('A soma dos valores que você enviou é de {}'.format(s))