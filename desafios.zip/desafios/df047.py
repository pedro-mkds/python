#Program que mostra todos os números pares que estão em um intervalo de 1 e 50

print('Esse programa mostra todos os números pares que estão em um intervalo de 1 e 50')
for c in range(2, 51, 2):
    print(c)
print('fim')
