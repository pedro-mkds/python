print('Vamos calcular sua média: ')
n1=int(input('Me de sua primeira nota: '))
n2=int(input('Me de sua segunda nota'))
n3=int(input('Me de a sua terceira nota'))

m=(n1+n2+n3)/3

print('Sua média final é de {}'.format(m))