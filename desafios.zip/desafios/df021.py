cid = str(input('Em que cidade vc mora? ')).strip()
cid2 = cid.title().strip()
print(cid2[:5] == 'Santo') 