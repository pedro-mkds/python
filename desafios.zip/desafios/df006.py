print('Vamos converter metros em centímetros e milímetros')
m= int(input('Digite uma quantia em metros: '))

cm= m*100
mm= m*1000

print('{} metro(s) é a mesma coisa que {}cm e {}mm'.format(m,cm,mm))
