#programa que le se um número é par ou ímpar

nmr = int(input('Digite um número: '))

if nmr % 2 == 0:
  print('O número {} é par!'.format(nmr))
else:
  print('O número {} é ímpar!'.format(nmr)) 