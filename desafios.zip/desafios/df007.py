v= int(input('Não sabe a tabuada de algum número? Deixa que eu te ajudo, me diga qual tabuada você tem dúvida ou não sabe: '))

v1=v*1
v2=v*2
v3=v*3
v4=v*4
v5=v*5
v6=v*6
v7=v*7
v8=v*8
v9=v*9
v10=v*10

print('A tabuada do número {} é: \n {}x1={} \n {}x2={} \n {}x3={} \n {}x4={} \n {}x5={} \n {}x6={} \n {}x7={} \n {}x8={} \n {}x9={} \n {}x10={} \n Está é a tabuada de 1 a 10 do número {}'.format(v,v,v1,v,v2,v,v3,v,v4,v,v5,v,v6,v,v7,v,v8,v,v9,v,v10,v))