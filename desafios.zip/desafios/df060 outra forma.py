#Programa que calcula um fatorial
from math import factorial
n = int(input('Digite um número: '))
f = factorial(n)

print(f'{f}')

