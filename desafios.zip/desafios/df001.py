nome= input('Digite seu nome!')
print('Olá', nome, '! Seja bem vindo!')

dia= input('Qual o dia que você nasceu?')
mes= input('Em qual mês você nasceu?')
ano= input('Em que ano você nasceu?')
print(nome, 'que legal te conhecer mais, agora sua data de nascimento', dia, 'de', mes, 'de', ano, 'ficara salva!')

nmr01= input('Que legal né? Agora para te mostrarei como sou bom de cálculos, me de um número')
nmr02= input('Agora me de outro número.')
print('A soma do seus números foi de', nmr01+nmr02)
